Kansas county clerk letters (DRAFT, for review before mailing)
Drafted for Morissa Benson by the Kansas Election Analysis bot, adapted from her Nebraska 93-county CVR request letter, in the same tone and structure as the Texas clerk letters.
One letter per county, addressed to that county's election officer (the elected county clerk in 101 counties; the appointed election commissioner in Johnson, Sedgwick, Shawnee and Wyandotte), in PDF and Word (.docx).
Addressees and mailing addresses: Kansas Secretary of State, All County Election Officers Information, https://www.sos.ks.gov/elections/county_election_officers_all.aspx, retrieved November 24, 2026 (America/Chicago).
Grouping: Kansas Department of Transportation's six districts, https://www.ksdot.gov/about/our-organization/districts. The Kansas Secretary of State does not divide the state into election regions; this grouping is only for convenience.
2026 figures in the letters are UNOFFICIAL (Kansas SOS election-night results, updated 11/08/2026; state certification scheduled Dec 1, 2026).
Date, signature, and sender blocks are blank on purpose. Confirm each addressee before sending. Nothing has been sent.

Counties in this file (18): Cheyenne, Decatur, Ellis, Gove, Graham, Logan, Norton, Osborne, Phillips, Rawlins, Rooks, Russell, Sheridan, Sherman, Smith, Thomas, Trego, Wallace
